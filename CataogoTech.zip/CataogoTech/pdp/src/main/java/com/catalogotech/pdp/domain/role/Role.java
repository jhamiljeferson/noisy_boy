package com.catalogotech.pdp.domain.role;

public enum Role {
    ADMIN, VENDEDOR;
}
