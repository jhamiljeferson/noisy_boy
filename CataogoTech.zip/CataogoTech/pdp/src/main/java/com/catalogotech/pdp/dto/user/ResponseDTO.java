package com.catalogotech.pdp.dto.user;


public record ResponseDTO (String nome, String token) { }