package com.catalogotech.pdp.dto.CategoriaDTO;

import jakarta.validation.constraints.NotNull;

public record DadosAtualizacaoCategoria(
        String nome
) {
}
