package com.catalogotech.pdp.domain.Fornecedor;

public enum TipoPessoa {
    FISICA,
    JURIDICA
}
