package com.catalogotech.pdp.dto.user;

public record LoginRequestDTO (String email, String senha){}


