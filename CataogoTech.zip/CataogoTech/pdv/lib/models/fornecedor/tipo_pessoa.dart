enum TipoPessoa { FISICA, JURIDICA }
